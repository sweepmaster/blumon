package com.example.blumon.procesamientoPago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcesamientoPagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
