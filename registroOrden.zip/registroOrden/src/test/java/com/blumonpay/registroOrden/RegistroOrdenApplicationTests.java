package com.blumonpay.registroOrden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistroOrdenApplicationTests {

	@Test
	void contextLoads() {
	}

}
